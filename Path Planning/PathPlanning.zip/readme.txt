The input txt file is where the obstacles, start node and end node.

Run program with "python3 PathPlanning.py"

Done by Rifumo Mzimba and Wesley Stander
